﻿using System;
using System.Drawing;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace EMEDIAPLS
{
    class Obsluga_obrazka
    {
        List<byte> kluczxor = new List<byte>(); // LISTA bajtów, w której przechowywane będą bajty klucza do XORA ( wczytywane z pliku key.txt )
        List<byte> naglowek_1 = new List<byte>(); /* Lista bajtów, w której znajdowane są bajty z informacjami o rozmiarze pliku ( zgodnie z wiki zaczyna się od bajtu 0x00C0)
        Jakby się pytał Makuchowski skąd wziąłeś, że akurat tam 5 i 6 bajt odpowiadają za szerokość/wysokość to mówisz, że na debugu odpaliłeś program, i sprawdziłeś które bajty mają
        taką wartość jak szerokość, kiedy klikasz prawym na obrazek i wchodzisz w zakładkę "sczegóły"*/
        List<byte> naglowek_2 = new List<byte>(); // Lista bajtów, w której znajdowane są bajty z infromacjami o rozdzielczościach pionowej i poziomej w dppi albo w dots / cm.
        public byte[] obrazek_w_bajtach; // Tablica bajtów, w której będzie przechowywany obrazek.
        string my_filename; // nazwa pliku
        public Obsluga_obrazka(string file_name) // Konstruktor Twojej klasy. Podczas tworzenia obiektu typu "Obsluga_obrazka" podajesz nazwę obrazka i on od razu robi tyle:
        {
            var keys = File.ReadLines("key.txt"); // Ustawia sobie klucz z pliku key.txt
            foreach (var key in keys) // Dla każdego klucza w kluczach ( plik skkłada się z 1000 linijek i to działa jak w pythonie for line in file )
            {
                kluczxor.Add((byte)(int.Parse(key))); // Do listy kluczów dodajesz klucz. Ważne jest to, żę stringa najpierw parsujesz na inta, a później rzutujesz na bajt. (str(3) -> int(3) -> bajt(3)) 
            }
            my_filename = file_name; // Jako zmienną w klasie my_filename ustawiasz podaną w argumencie konstruktora nazwę pliku
            obrazek_w_bajtach = File.ReadAllBytes(file_name); // Funkcja, która wczytuje wszystkie bajty w obrazku.
            if (!(obrazek_w_bajtach[0] == 0x00FF && obrazek_w_bajtach[1] == 0x00D8)) /* Sprawdzasz czy pierwsze dwa bajty mają wartości 255 ( 16*15 + 15 ( FF ) oraz 216 ).
                Info to jest brane z angielskiej wikipedii ( wpisz w google jpg wiki i wejdź na angielską). Tam jest, że każdy jpg się tak zaczyna.*/
            { Console.WriteLine("Wrong file type"); return; } // Jak nie taki plik to się kończy porgram i zaraz się wykrzaczy w dalszej części funkcji main.

            for (int i = 2; i < obrazek_w_bajtach.Length; i++) // Jak się wszystko zgadza to lecisz po całym obrazku i znów szukasz odpowiednich początków danych ( tabelka na ang. wiki)
            {
                if ((obrazek_w_bajtach[i] == 0x00C0 || obrazek_w_bajtach[i] == 0x00E0) && obrazek_w_bajtach[i - 1] == 0x00FF) // Jak początki są odpowiednie to:
                {
                    byte sekcjaNaglowka = obrazek_w_bajtach[i]; i++; // Tutaj po prostu zapamietujesz w której części nagłówka jesteś w zmiennej sekcja_Naglowka
                    while (sekcjaNaglowka == 0x00C0 && obrazek_w_bajtach[i] != 0x00ff) { naglowek_1.Add(obrazek_w_bajtach[i]); i++;  } // Sczytujesz jeden do pierwszej części ( tam gdzie jest info o rozmiarze)
                    while (sekcjaNaglowka == 0x00E0 && obrazek_w_bajtach[i] != 0x00ff) { naglowek_2.Add(obrazek_w_bajtach[i]); i++; } // Sczytujesz drugi kawałek informacji do drugiej części ( tam gdzie info o rozdzielczości )
                }
            }
        }

        public void show_header()
        {
             //Dałem tylko try catche, bo jakby nie znalazł nagłówka to lipa i wykrzaczy program. 
            try //Dałem tylko try catche, bo jakby nie znalazł nagłówka to lipa i wykrzaczy program. 
            {
                Console.WriteLine("Informacje sczytane z nagłówka");
                Console.WriteLine("Szerokość obrazka w pikselach: " + (naglowek_1[5] * 256 + naglowek_1[6]).ToString()); /* Wypisujessz po kolei dane odwołując się do dobrych cześci nagłówka ( info z prawym na obrazek -> sczegóły, albo z neta
                Ogólnie dlaczego jest to 256? No bo bajty mają zakres 0-255. I jak obrazek ma wymiar np 1046 to nie zmieści się w jednym bajcie tylko w dwóch. I to jest jak system szestnastkowy F8 = 16*15 + 8
                tylko tyle, że to system 256. Czyli jak masz dwucyfrową liczbę, to pierwsza cyfra to jest 256^1 * jej wartość a druga 256^0 razy jej wartośc. */
                Console.WriteLine("Wysokość obrazka w pikselach: " + (naglowek_1[3] * 256 + naglowek_1[4]).ToString());
            }
            catch
            {
                Console.WriteLine("Nie znaleziono nagłówka pliku, w którym są dane o rozmiarze");
            }
            try
            {
                if (naglowek_2[9] == 0x0001)
                {
                    Console.WriteLine("Rozdzielczość pozioma obrazka w dpi: " + (naglowek_2[10] * 256 + naglowek_2[11]).ToString()); //Wszystko to samo. 
                    Console.WriteLine("Rozdzielczość pionowa obrazka w dpi: " + (naglowek_2[12] * 256 + naglowek_2[13]).ToString());
                }
                else
                {
                    Console.WriteLine("Rozdzielczosć pozioma obrazka w d/cm: " + (naglowek_2[10] * 256 + naglowek_2[11]).ToString());
                    Console.WriteLine("Rozdzielczość pionowa obrazka w d/cm: " + (naglowek_2[12] * 256 + naglowek_2[13]).ToString());
                }
                Console.WriteLine("Wersja pliku jpg: " + (naglowek_2[7]).ToString() + "." + (naglowek_2[8]).ToString());
            }
            catch
            {
                Console.WriteLine("Nie znaleziono nagłówka pliku, gdzie są dane o rozdzielczościach i wersji jpg");
            }
            }

        public byte[] encrypt_decrypt_XOR(byte[] data, int start) // Enkrypcja i dekrycpja XOREM!!! Pobierasz tylko danę do zaszyfrowania / odszyfrowania bo klucz masz w klasie.
        {
            byte[] output = new byte[data.Length]; // Przygotowujesz sobie tablice do stworzenia wyjscia po operacji.
            for (int i=0; i< data.Length;)
            {
                while (i < start) { output[i] = data[i]; i++; } // Int start definiuje od ktorego bitu szyfrujemy. Jak np od 1000, to pierwsze 1000 elementów jest przepisanych bez XORa, z obrazka.
                for (int j=0; j<kluczxor.Count()-1; j++) // Potem się leci po kluczu w pęli i szyfruje.
                {
                   
                    if(i< data.Length)
                    {
                        output[i] = (byte)(data[i] ^ kluczxor[j]); // Symbol ^ jest definicją XORA, ale dziala na intach, wiec potem trzeba znow rzutować na bajt poprzez (byte) - nawias potrzebny.
                        i++;
                    }
                    
                }
            }
            return output;
        }

        public Bitmap CreateImageFromBytes(byte[] image)
        {
            try
            {
                return new Bitmap(Image.FromStream(new MemoryStream(image))); // Tutaj po prostu próbujesz zapisać te bajty znów w postaci obrazka
            }
            catch
            {
                Console.WriteLine("Nagłówek pliku został uszkodzony! Zapisano oryginalny obrazek");  // Jak cos nie pyklo to pewnie naglowek zaszyfrowany i wtedy on topoznaje jako inny format pliku
                return new Bitmap(Image.FromStream(new MemoryStream(obrazek_w_bajtach)));
            }
        }
    }

    class Program
    {
        static void Main(string[] args)
        {
            while (true)
            {

                System.Console.WriteLine("Podaj nazwę pliku. Zostanie wyświetlony jego nagłówek, a następnie zostanie on zaszyfrowany zgodnie z kluczem.");
                System.Console.WriteLine("Zaszyfrowany obrazek nadpisze plik Encrypted_Image_XOR.jpg, jeśli uda się go poprawnie odczytać.");
                System.Console.WriteLine("Następnie nastąpi deszyfracja i zdeszyfrowany obrazek zapisany zostanie w pliku Decrypted_Image_XOR.jpg.");
                System.Console.WriteLine("Nazwa pliku:"); // Menu jak widac
                var filename = Console.ReadLine(); // Tworzysz sobie nazwe pliku wczytujac z konsoli
                Obsluga_obrazka myImage = new Obsluga_obrazka(filename); // Robisz obiekt klasy od tej nazwy.
                myImage.show_header();// Wyswietlasz info o headerze
                var original = myImage.obrazek_w_bajtach; //Bierzesz oryginalne dane z obrazka.
                var encrypted = myImage.encrypt_decrypt_XOR(original, 1500); // Szyfrujesz je /
                Bitmap encrypImg = myImage.CreateImageFromBytes(encrypted); // Do postaci obrazka
                encrypImg.Save("Encrypted_Image_XOR.jpg", System.Drawing.Imaging.ImageFormat.Jpeg); // Zapisujesz go jako jpg
                var decrypted = myImage.encrypt_decrypt_XOR(encrypted, 1500); // Deszyfrujesz
                Bitmap decrypImg = myImage.CreateImageFromBytes(decrypted);// Znow do obrazka
                decrypImg.Save("Decrypted_Image_XOR.jpg", System.Drawing.Imaging.ImageFormat.Jpeg); // Zapis obrazka

            }
        }
    }

}
